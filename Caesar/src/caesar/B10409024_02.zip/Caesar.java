package caesar;

public class Caesar {
    private String plaintext;
    public String getPlaintext(){
        return plaintext;
    }
    public void setPlaintext(String plaintext){
        this.plaintext=plaintext;
    }
}
